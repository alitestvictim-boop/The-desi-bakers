// pm2 start ecosystem.config.js
module.exports = {
  apps: [{
    name: 'desi-bakers',
    script: 'server.js',
    env: {
      PORT: 3000,
      // First run only: set your own admin login here (then change it in the panel)
      // ADMIN_EMAIL: 'owner@example.com',
      // ADMIN_PASSWORD: 'a-strong-password',
    },
  }],
};
