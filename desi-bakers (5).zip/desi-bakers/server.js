'use strict';
/**
 * The Desi Bakers - website + admin panel server
 * Zero dependencies. Needs Node.js 18+ only.
 *   node server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const SECRET_FILE = path.join(DATA_DIR, 'secret.key');
const SESSION_DAYS = 7;

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

/* ------------------------------------------------------------------ */
/* Secret + password helpers                                           */
/* ------------------------------------------------------------------ */
let SECRET;
if (fs.existsSync(SECRET_FILE)) {
  SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
} else {
  SECRET = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SECRET_FILE, SECRET, { mode: 0o600 });
}

function hashPw(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
}
function checkPw(pw, stored) {
  try {
    const [salt, h] = stored.split(':');
    const test = crypto.scryptSync(String(pw), salt, 64);
    return crypto.timingSafeEqual(test, Buffer.from(h, 'hex'));
  } catch {
    return false;
  }
}
const uid = () => crypto.randomBytes(6).toString('hex');

/* ------------------------------------------------------------------ */
/* Database (single JSON file, written atomically)                     */
/* ------------------------------------------------------------------ */
function seed() {
  const email = (process.env.ADMIN_EMAIL || 'admin@thedesibakers.com').toLowerCase();
  const password = process.env.ADMIN_PASSWORD || 'Admin@12345';
  const cat = (id, name, group, emoji, order) => ({ id, name, group, emoji, order });
  const categories = [
    cat('c-pastries', 'Pastries', 'bakery', '🧁', 1),
    cat('c-cakes', 'Cakes', 'bakery', '🎂', 2),
    cat('c-patties', 'Patties', 'bakery', '🥧', 3),
    cat('c-frozen', 'Frozen Items', 'bakery', '🧊', 4),
    cat('c-biryani', 'Biryani', 'food', '🍛', 5),
    cat('c-pulao', 'Pulao', 'food', '🍚', 6),
  ];
  const it = (name, categoryId, price, description, featured = false) => ({
    id: uid(), name, categoryId, price, description, image: '', available: true, featured,
  });
  const items = [
    it('Chocolate Pastry', 'c-pastries', 150, 'Soft sponge with rich chocolate cream.', true),
    it('Black Forest Pastry', 'c-pastries', 180, 'Cherry and whipped cream layers.'),
    it('Chocolate Fudge Cake (2 lb)', 'c-cakes', 2200, 'Moist chocolate cake with fudge frosting.', true),
    it('Vanilla Cake (2 lb)', 'c-cakes', 1800, 'Classic vanilla cake with fresh cream.'),
    it('Chicken Patty', 'c-patties', 120, 'Flaky puff pastry with spiced chicken filling.', true),
    it('Aloo Patty', 'c-patties', 80, 'Crispy patty with potato masala.'),
    it('Chicken Samosa (Frozen, 12 pcs)', 'c-frozen', 650, 'Ready to fry. Keep frozen.'),
    it('Chicken Biryani (Single)', 'c-biryani', 350, 'Aromatic basmati rice with tender chicken.', true),
    it('Chicken Biryani (Family)', 'c-biryani', 1400, 'Serves 4 to 5 people.'),
    it('Chicken Pulao (Single)', 'c-pulao', 300, 'Lightly spiced yakhni pulao.'),
  ];
  const deals = [{
    id: uid(),
    title: 'Sample Family Deal (edit me)',
    description: 'This is a sample deal. Edit or delete it from the admin panel.',
    includes: '1 Family Biryani, 6 Patties, 1 Cold Drink',
    price: 2200, oldPrice: 2600, image: '', active: true, validTill: '',
  }];
  const db = {
    admin: { email, passHash: hashPw(password), pv: uid(), mustChange: !process.env.ADMIN_PASSWORD },
    settings: {
      businessName: 'The Desi Bakers',
      tagline: 'Fresh bakes, desi taste',
      heroTitle: 'Freshly baked, every single day',
      heroText: 'Pastries, cakes, patties, frozen items and mouth-watering biryani & pulao. Made fresh, made with love.',
      phone: '0300-0000000',
      whatsapp: '923000000000',
      email: 'info@thedesibakers.com',
      address: 'Shop address here',
      hours: 'Every day: 9:00 AM to 11:00 PM',
      facebook: '',
      instagram: '',
    },
    categories, items, deals, reviews: [],
  };
  console.log('\n  First run: admin account created');
  console.log('  Email   :', email);
  console.log('  Password:', password);
  console.log('  Login at /admin and change the password straight away.\n');
  return db;
}

let db;
if (fs.existsSync(DB_FILE)) {
  db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
} else {
  db = seed();
  saveDb();
}
function saveDb() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

/* ------------------------------------------------------------------ */
/* Validation schema for the 4 content types                           */
/* ------------------------------------------------------------------ */
const LONG = new Set(['description', 'text', 'includes']);
const SCHEMA = {
  categories: {
    fields: { name: 's', group: 's', emoji: 's', order: 'n' },
    defaults: () => ({ name: '', group: 'bakery', emoji: '🍰', order: 99 }),
    required: ['name'],
  },
  items: {
    fields: { name: 's', categoryId: 's', price: 'n', description: 's', image: 'i', available: 'b', featured: 'b' },
    defaults: () => ({ name: '', categoryId: '', price: 0, description: '', image: '', available: true, featured: false }),
    required: ['name', 'categoryId'],
  },
  deals: {
    fields: { title: 's', description: 's', includes: 's', price: 'n', oldPrice: 'n', image: 'i', active: 'b', validTill: 'd' },
    defaults: () => ({ title: '', description: '', includes: '', price: 0, oldPrice: 0, image: '', active: true, validTill: '' }),
    required: ['title'],
  },
  reviews: {
    fields: { name: 's', rating: 'n', text: 's', approved: 'b' },
    defaults: () => ({ name: '', rating: 5, text: '', approved: true }),
    required: ['name', 'text'],
  },
};

function fail(msg) {
  const e = new Error(msg);
  e.status = 400;
  return e;
}

function applyFields(type, target, input) {
  const sc = SCHEMA[type];
  for (const [k, t] of Object.entries(sc.fields)) {
    if (!(k in input)) continue;
    const v = input[k];
    if (t === 's') target[k] = String(v ?? '').trim().slice(0, LONG.has(k) ? 1500 : 150);
    else if (t === 'n') {
      const n = Number(v);
      if (!Number.isFinite(n) || n < 0 || n > 10000000) throw fail(`Invalid number for ${k}`);
      target[k] = n;
    } else if (t === 'b') target[k] = !!v;
    else if (t === 'i') {
      const s = String(v ?? '').trim();
      if (s && !/^\/uploads\/[a-f0-9]+\.(png|jpg|webp|gif)$/.test(s) && !/^https:\/\//.test(s)) throw fail('Invalid image');
      target[k] = s.slice(0, 500);
    } else if (t === 'd') {
      const s = String(v ?? '').trim();
      if (s && !/^\d{4}-\d{2}-\d{2}$/.test(s)) throw fail('Invalid date');
      target[k] = s;
    }
  }
  // cross-field rules
  for (const r of sc.required) if (!String(target[r] ?? '').trim()) throw fail(`${r} is required`);
  if (type === 'categories' && !['bakery', 'food'].includes(target.group)) throw fail('Invalid group');
  if (type === 'items' && !db.categories.some((c) => c.id === target.categoryId)) throw fail('Choose a valid category');
  if (type === 'reviews') target.rating = Math.min(5, Math.max(1, Math.round(target.rating)));
}

/* ------------------------------------------------------------------ */
/* Image cleanup                                                       */
/* ------------------------------------------------------------------ */
function imageStillUsed(url) {
  return db.items.some((i) => i.image === url) || db.deals.some((d) => d.image === url);
}
function cleanupImage(url) {
  if (!url || !url.startsWith('/uploads/') || imageStillUsed(url)) return;
  const file = path.join(UPLOAD_DIR, path.basename(url));
  fs.unlink(file, () => {});
}

/* ------------------------------------------------------------------ */
/* HTTP helpers                                                        */
/* ------------------------------------------------------------------ */
function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  return (xf ? xf.split(',')[0].trim() : req.socket.remoteAddress) || 'unknown';
}
function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, {
    'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    ...headers,
  });
  res.end(isObj ? JSON.stringify(body) : body);
}
function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(Object.assign(new Error('Request too large'), { status: 413 }));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(fail('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

/* simple in-memory rate limiter */
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) {
    hits.set(key, arr);
    return true;
  }
  arr.push(now);
  hits.set(key, arr);
  return false;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of hits) if (!arr.some((t) => now - t < 3600e3)) hits.delete(k);
}, 600e3).unref();

/* ------------------------------------------------------------------ */
/* Sessions (signed cookie, survives restarts)                         */
/* ------------------------------------------------------------------ */
const sign = (data) => crypto.createHmac('sha256', SECRET).update(data).digest('base64url');

function makeSession() {
  const payload = Buffer.from(JSON.stringify({ e: db.admin.email, pv: db.admin.pv, x: Date.now() + SESSION_DAYS * 864e5 })).toString('base64url');
  return payload + '.' + sign(payload);
}
function getSession(req) {
  const m = /(?:^|;\s*)dbsid=([^;]+)/.exec(req.headers.cookie || '');
  if (!m) return null;
  const [payload, sig] = m[1].split('.');
  if (!payload || !sig) return null;
  const expected = sign(payload);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const p = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (p.x < Date.now() || p.e !== db.admin.email || p.pv !== db.admin.pv) return null;
    return p;
  } catch {
    return null;
  }
}
function cookieHeader(req, value, maxAge) {
  const secure = req.headers['x-forwarded-proto'] === 'https' || process.env.COOKIE_SECURE === '1';
  return `dbsid=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
}

/* ------------------------------------------------------------------ */
/* API                                                                 */
/* ------------------------------------------------------------------ */
const todayPK = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Karachi' });
const byOrder = (a, b) => (a.order ?? 99) - (b.order ?? 99) || a.name.localeCompare(b.name);

function publicData() {
  const today = todayPK();
  const reviews = db.reviews.filter((r) => r.approved).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
  return {
    settings: db.settings,
    categories: [...db.categories].sort(byOrder),
    items: db.items,
    deals: db.deals.filter((d) => d.active && (!d.validTill || d.validTill >= today)),
    reviews,
    rating: { average: Math.round(avg * 10) / 10, count: reviews.length },
  };
}

async function handleApi(req, res, url) {
  const route = url.pathname;
  const method = req.method;

  /* ---------- public ---------- */
  if (route === '/api/public' && method === 'GET') {
    return send(res, 200, publicData(), { 'Cache-Control': 'no-cache' });
  }

  if (route === '/api/reviews' && method === 'POST') {
    const ip = clientIp(req);
    if (limited('review:' + ip, 3, 3600e3)) return send(res, 429, { error: 'Too many reviews. Please try later.' });
    const b = await readBody(req, 20000);
    if (b.website) return send(res, 200, { ok: true }); // honeypot
    const name = String(b.name || '').trim().slice(0, 60);
    const text = String(b.text || '').trim().slice(0, 600);
    const rating = Math.round(Number(b.rating));
    if (!name || text.length < 3 || !(rating >= 1 && rating <= 5)) return send(res, 400, { error: 'Please fill name, rating and review.' });
    db.reviews.push({ id: uid(), name, rating, text, approved: false, date: new Date().toISOString() });
    saveDb();
    return send(res, 200, { ok: true });
  }

  /* ---------- admin login ---------- */
  if (route === '/api/admin/login' && method === 'POST') {
    const ip = clientIp(req);
    if (limited('login:' + ip, 8, 15 * 60e3)) return send(res, 429, { error: 'Too many attempts. Try again in 15 minutes.' });
    const b = await readBody(req, 5000);
    const emailOk = String(b.email || '').trim().toLowerCase() === db.admin.email;
    const passOk = checkPw(b.password || '', db.admin.passHash);
    if (!(emailOk && passOk)) return send(res, 401, { error: 'Wrong email or password.' });
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookieHeader(req, makeSession(), SESSION_DAYS * 86400) });
  }
  if (route === '/api/admin/logout' && method === 'POST') {
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookieHeader(req, '', 0) });
  }

  /* ---------- everything below needs login ---------- */
  if (route.startsWith('/api/admin/')) {
    if (!getSession(req)) return send(res, 401, { error: 'Not logged in' });
    if (method !== 'GET' && !String(req.headers['content-type'] || '').startsWith('application/json')) {
      return send(res, 415, { error: 'JSON only' });
    }

    if (route === '/api/admin/me' && method === 'GET') {
      return send(res, 200, { email: db.admin.email, mustChange: !!db.admin.mustChange });
    }

    if (route === '/api/admin/all' && method === 'GET') {
      return send(res, 200, {
        settings: db.settings,
        categories: [...db.categories].sort(byOrder),
        items: db.items,
        deals: [...db.deals].reverse(),
        reviews: [...db.reviews].sort((a, b) => Number(a.approved) - Number(b.approved) || (b.date || '').localeCompare(a.date || '')),
      }, { 'Cache-Control': 'no-store' });
    }

    if (route === '/api/admin/settings' && method === 'PUT') {
      const b = await readBody(req, 20000);
      for (const k of Object.keys(db.settings)) {
        if (k in b) db.settings[k] = String(b[k] ?? '').trim().slice(0, 400);
      }
      db.settings.whatsapp = db.settings.whatsapp.replace(/\D/g, '');
      saveDb();
      return send(res, 200, db.settings);
    }

    if (route === '/api/admin/account' && method === 'PUT') {
      const b = await readBody(req, 5000);
      if (!checkPw(b.currentPassword || '', db.admin.passHash)) return send(res, 400, { error: 'Current password is wrong.' });
      const newEmail = String(b.newEmail || '').trim().toLowerCase();
      const newPassword = String(b.newPassword || '');
      if (newEmail) {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) return send(res, 400, { error: 'Invalid email.' });
        db.admin.email = newEmail;
      }
      if (newPassword) {
        if (newPassword.length < 8) return send(res, 400, { error: 'New password must be at least 8 characters.' });
        db.admin.passHash = hashPw(newPassword);
        db.admin.pv = uid();
        db.admin.mustChange = false;
      }
      saveDb();
      return send(res, 200, { ok: true, email: db.admin.email }, { 'Set-Cookie': cookieHeader(req, makeSession(), SESSION_DAYS * 86400) });
    }

    if (route === '/api/admin/upload' && method === 'POST') {
      const b = await readBody(req);
      const m = /^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(String(b.data || ''));
      if (!m) return send(res, 400, { error: 'Only PNG, JPG, WEBP or GIF images are allowed.' });
      const buf = Buffer.from(m[2], 'base64');
      if (buf.length > 5 * 1024 * 1024) return send(res, 400, { error: 'Image is larger than 5 MB.' });
      const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
      const name = crypto.randomBytes(10).toString('hex') + '.' + ext;
      fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
      return send(res, 200, { url: '/uploads/' + name });
    }

    /* generic CRUD: /api/admin/<type>[/<id>] */
    const m = /^\/api\/admin\/(categories|items|deals|reviews)(?:\/([\w-]+))?$/.exec(route);
    if (m) {
      const type = m[1];
      const id = m[2];
      const list = db[type];

      if (method === 'POST' && !id) {
        const rec = { id: uid(), ...SCHEMA[type].defaults() };
        applyFields(type, rec, await readBody(req, 20000));
        if (type === 'reviews') rec.date = new Date().toISOString();
        list.push(rec);
        saveDb();
        return send(res, 201, rec);
      }
      const idx = list.findIndex((r) => r.id === id);
      if (idx < 0) return send(res, 404, { error: 'Not found' });

      if (method === 'PUT') {
        const rec = { ...list[idx] };
        const oldImage = rec.image;
        applyFields(type, rec, await readBody(req, 20000));
        list[idx] = rec;
        saveDb();
        if (oldImage && oldImage !== rec.image) cleanupImage(oldImage);
        return send(res, 200, rec);
      }
      if (method === 'DELETE') {
        if (type === 'categories' && db.items.some((i) => i.categoryId === id)) {
          return send(res, 400, { error: 'This category still has items. Move or delete them first.' });
        }
        const [removed] = list.splice(idx, 1);
        saveDb();
        cleanupImage(removed.image);
        return send(res, 200, { ok: true });
      }
    }
    return send(res, 404, { error: 'Not found' });
  }

  return send(res, 404, { error: 'Not found' });
}

/* ------------------------------------------------------------------ */
/* Static files                                                        */
/* ------------------------------------------------------------------ */
function serveFile(res, file, cache) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found');
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': cache,
      'X-Content-Type-Options': 'nosniff',
    });
    fs.createReadStream(file).pipe(res);
  });
}

function handleStatic(req, res, url) {
  let p;
  try {
    p = decodeURIComponent(url.pathname);
  } catch {
    return send(res, 400, 'Bad request');
  }
  if (p.includes('\0')) return send(res, 400, 'Bad request');

  if (p.startsWith('/uploads/')) {
    const file = path.join(UPLOAD_DIR, path.basename(p));
    return serveFile(res, file, 'public, max-age=604800');
  }

  const base = path.resolve(PUBLIC_DIR);
  const candidates = [p, p + '.html', path.join(p, 'index.html')];
  for (const c of candidates) {
    const full = path.resolve(path.join(base, c));
    if (!full.startsWith(base + path.sep) && full !== base) continue;
    try {
      if (fs.statSync(full).isFile()) return serveFile(res, full, 'no-cache');
    } catch { /* try next */ }
  }
  const nf = path.join(base, '404.html');
  res.statusCode = 404;
  if (fs.existsSync(nf)) {
    res.setHeader('Content-Type', MIME['.html']);
    return res.end(fs.readFileSync(nf));
  }
  return send(res, 404, 'Not found');
}

/* ------------------------------------------------------------------ */
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
    return handleStatic(req, res, url);
  } catch (e) {
    if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : 'Server error' });
    if (!e.status) console.error(e);
  }
});

server.listen(PORT, () => console.log(`The Desi Bakers running on http://localhost:${PORT}  (admin: /admin)`));
