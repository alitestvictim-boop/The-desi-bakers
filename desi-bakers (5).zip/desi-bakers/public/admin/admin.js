/* The Desi Bakers - admin dashboard */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => (Number(n) > 0 ? 'Rs. ' + Number(n).toLocaleString('en-PK') : '-');

  let D = null;          // data from server
  let me = null;
  let tab = location.hash.slice(1) || 'dashboard';
  let itemFilter = 'all';

  /* ---------- api ---------- */
  async function api(method, url, body) {
    const r = await fetch(url, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : (method === 'GET' ? {} : { 'Content-Type': 'application/json' }),
      body: body ? JSON.stringify(body) : (method === 'GET' ? undefined : '{}'),
    });
    if (r.status === 401 && !url.endsWith('/login')) { location.replace('/admin/login'); throw new Error('Login required'); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'Something went wrong');
    return j;
  }
  async function reload() { D = await api('GET', '/api/admin/all'); }

  let toastT;
  function toast(msg, err) {
    const t = $('#toast');
    t.textContent = msg; t.className = 'toast show' + (err ? ' err' : '');
    clearTimeout(toastT); toastT = setTimeout(() => (t.className = 'toast'), 2600);
  }
  async function run(fn, okMsg) {
    try { await fn(); if (okMsg) toast(okMsg); await reload(); render(); } catch (e) { toast(e.message, true); }
  }

  /* ---------- image compress + upload ---------- */
  function fileToDataUrl(file, max = 1100) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = () => reject(new Error('Could not read image'));
      fr.onload = () => {
        if (file.type === 'image/gif') return resolve(fr.result);
        const img = new Image();
        img.onerror = () => reject(new Error('Not a valid image'));
        img.onload = () => {
          const k = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement('canvas');
          c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', 0.85));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }

  /* ---------- section config ---------- */
  const catOptions = () => D.categories.map((c) => ({ v: c.id, t: `${c.emoji} ${c.name}` }));
  const SECTIONS = {
    deals: {
      label: 'Deals', icon: '🎁', singular: 'Deal', api: 'deals',
      fields: () => [
        { k: 'title', t: 'text', label: 'Deal title', req: true, full: true },
        { k: 'includes', t: 'text', label: 'What is included', hint: 'e.g. 1 Family Biryani, 6 Patties, 1 Cold Drink', full: true },
        { k: 'description', t: 'textarea', label: 'Description', full: true },
        { k: 'price', t: 'number', label: 'Deal price (Rs.)' },
        { k: 'oldPrice', t: 'number', label: 'Old price (Rs.)', hint: 'Optional. Shows discount %' },
        { k: 'validTill', t: 'date', label: 'Valid till', hint: 'Optional. Deal hides itself after this date' },
        { k: 'active', t: 'check', label: 'Show on website' },
        { k: 'image', t: 'image', label: 'Photo', full: true },
      ],
    },
    items: {
      label: 'Menu Items', icon: '🍰', singular: 'Item', api: 'items',
      fields: () => [
        { k: 'name', t: 'text', label: 'Item name', req: true, full: true },
        { k: 'categoryId', t: 'select', label: 'Category', options: catOptions(), req: true },
        { k: 'price', t: 'number', label: 'Price (Rs.)' },
        { k: 'description', t: 'textarea', label: 'Description', full: true },
        { k: 'available', t: 'check', label: 'Available (untick = shows "Sold out")' },
        { k: 'featured', t: 'check', label: 'Show as Popular on home page' },
        { k: 'image', t: 'image', label: 'Photo', full: true },
      ],
    },
    categories: {
      label: 'Categories', icon: '🗂️', singular: 'Category', api: 'categories',
      fields: () => [
        { k: 'name', t: 'text', label: 'Category name', req: true },
        { k: 'emoji', t: 'text', label: 'Emoji icon', hint: 'e.g. 🎂 🥟 🍛' },
        { k: 'group', t: 'select', label: 'Section on menu', options: [{ v: 'bakery', t: 'Bakery section' }, { v: 'food', t: 'Biryani & Food section' }], req: true },
        { k: 'order', t: 'number', label: 'Display order', hint: 'Smaller number shows first' },
      ],
    },
    reviews: {
      label: 'Reviews', icon: '⭐', singular: 'Review', api: 'reviews',
      fields: () => [
        { k: 'name', t: 'text', label: 'Customer name', req: true },
        { k: 'rating', t: 'select', label: 'Rating', options: [5, 4, 3, 2, 1].map((n) => ({ v: n, t: '★'.repeat(n) + ' (' + n + ')' })) },
        { k: 'text', t: 'textarea', label: 'Review', req: true, full: true },
        { k: 'approved', t: 'check', label: 'Approved (show on website)' },
      ],
    },
  };

  /* ---------- modal form ---------- */
  function openForm(secKey, rec) {
    const sec = SECTIONS[secKey];
    const isNew = !rec;
    const data = rec ? { ...rec } : defaults(secKey);
    $('#mtitle').textContent = (isNew ? 'Add ' : 'Edit ') + sec.singular;
    const form = $('#mform');
    form.innerHTML = `<div class="fgrid">${sec.fields().map((f) => fieldHtml(f, data[f.k])).join('')}</div>
      <div class="form-actions"><button type="button" class="btn" id="mcancel">Cancel</button><button class="btn primary" type="submit">Save</button></div>`;
    $('#modal').hidden = false;

    // image field wiring
    const imgF = sec.fields().find((f) => f.t === 'image');
    if (imgF) {
      const input = form.querySelector('[name="__file"]');
      input.onchange = async () => {
        const f = input.files[0];
        if (!f) return;
        try {
          const dataUrl = await fileToDataUrl(f);
          toast('Uploading photo...');
          const r = await api('POST', '/api/admin/upload', { data: dataUrl });
          data[imgF.k] = r.url;
          form.querySelector('.img-prev').innerHTML = `<img src="${esc(r.url)}" alt="">`;
          form.querySelector('[data-rm]').hidden = false;
          toast('Photo ready. Press Save.');
        } catch (e) { toast(e.message, true); }
      };
      form.querySelector('[data-rm]').onclick = () => {
        data[imgF.k] = '';
        form.querySelector('.img-prev').textContent = '🖼️';
        form.querySelector('[data-rm]').hidden = true;
      };
    }
    $('#mcancel').onclick = closeForm;
    form.onsubmit = async (e) => {
      e.preventDefault();
      const out = {};
      for (const f of sec.fields()) {
        if (f.t === 'image') out[f.k] = data[f.k] || '';
        else if (f.t === 'check') out[f.k] = form.elements[f.k].checked;
        else out[f.k] = form.elements[f.k].value;
      }
      const btn = form.querySelector('button[type=submit]');
      btn.disabled = true;
      try {
        if (isNew) await api('POST', `/api/admin/${sec.api}`, out);
        else await api('PUT', `/api/admin/${sec.api}/${rec.id}`, out);
        closeForm(); toast('Saved'); await reload(); render();
      } catch (err) { toast(err.message, true); btn.disabled = false; }
    };
    const first = form.querySelector('input[type=text], select');
    if (first) first.focus();
  }
  function closeForm() { $('#modal').hidden = true; }
  $('#mclose').onclick = closeForm;
  $('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal') closeForm(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeForm(); });

  function defaults(k) {
    if (k === 'deals') return { active: true, price: '', oldPrice: '', validTill: '' };
    if (k === 'items') return { available: true, featured: false, price: '', categoryId: itemFilter !== 'all' ? itemFilter : D.categories[0]?.id };
    if (k === 'categories') return { group: 'bakery', emoji: '🍰', order: D.categories.length + 1 };
    if (k === 'reviews') return { rating: 5, approved: true };
    return {};
  }

  function fieldHtml(f, v) {
    const cls = 'f' + (f.full ? ' full' : '') + (f.t === 'check' ? ' check' : '');
    const hint = f.hint ? `<small>${esc(f.hint)}</small>` : '';
    let inner;
    if (f.t === 'textarea') inner = `<label>${esc(f.label)}</label><textarea name="${f.k}" rows="3" maxlength="1500">${esc(v ?? '')}</textarea>${hint}`;
    else if (f.t === 'select') inner = `<label>${esc(f.label)}</label><select name="${f.k}">${f.options.map((o) => `<option value="${esc(o.v)}" ${String(o.v) === String(v) ? 'selected' : ''}>${esc(o.t)}</option>`).join('')}</select>${hint}`;
    else if (f.t === 'check') inner = `<label><span class="switch"><input type="checkbox" name="${f.k}" ${v ? 'checked' : ''}><span></span></span>${esc(f.label)}</label>`;
    else if (f.t === 'image') inner = `<label>${esc(f.label)}</label><div class="img-field"><div class="img-prev">${v ? `<img src="${esc(v)}" alt="">` : '🖼️'}</div>
        <div><input type="file" name="__file" accept="image/*"><br><button type="button" class="btn sm danger" data-rm style="margin-top:6px" ${v ? '' : 'hidden'}>Remove photo</button></div></div>`;
    else inner = `<label>${esc(f.label)}${f.req ? ' *' : ''}</label><input type="${f.t}" name="${f.k}" value="${esc(v ?? '')}" ${f.req ? 'required' : ''} ${f.t === 'number' ? 'min="0" step="any"' : 'maxlength="150"'}>${hint}`;
    return `<div class="${cls}">${inner}</div>`;
  }

  /* ---------- views ---------- */
  const thumb = (img, emoji) => (img ? `<img class="thumb" src="${esc(img)}" alt="">` : `<div class="thumb">${emoji}</div>`);
  const catName = (id) => { const c = D.categories.find((x) => x.id === id); return c ? `${c.emoji} ${c.name}` : '-'; };
  const toggle = (checked, attrs) => `<label class="switch"><input type="checkbox" ${checked ? 'checked' : ''} ${attrs}><span></span></label>`;

  function viewDashboard() {
    const pending = D.reviews.filter((r) => !r.approved).length;
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Karachi' });
    const live = D.deals.filter((d) => d.active && (!d.validTill || d.validTill >= today)).length;
    return `
      ${me.mustChange ? `<div class="alert warn">⚠️ You are using the default password. Please change it in <a href="#account" data-go="account">Account</a>.</div>` : ''}
      <div class="stats">
        <div class="stat" data-go="deals"><b>${live}</b><span>Live deals</span></div>
        <div class="stat" data-go="items"><b>${D.items.length}</b><span>Menu items</span></div>
        <div class="stat" data-go="categories"><b>${D.categories.length}</b><span>Categories</span></div>
        <div class="stat" data-go="reviews"><b>${pending}</b><span>Reviews waiting approval</span></div>
      </div>
      <div class="panel"><h3>Quick actions</h3><p class="hint">The most common jobs, one tap away.</p>
        <div class="bar"><button class="btn primary" data-add="deals">+ New deal</button><button class="btn primary" data-add="items">+ New item</button><button class="btn" data-go="reviews">Check reviews</button></div></div>
      <div class="panel"><h3>How it works</h3>
        <p class="hint" style="margin:0">• <b>Deals</b>: add a deal with photo and price. It appears on the website Deals page straight away.<br>
        • <b>Menu Items</b>: pick a category (Pastries, Cakes, Patties, Frozen, Biryani, Pulao...) and add items.<br>
        • <b>Categories</b>: add new ones and choose if they go in the Bakery section or the Biryani & Food section.<br>
        • <b>Reviews</b>: customer reviews wait here until you approve them.</p></div>`;
  }

  function viewDeals() {
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Karachi' });
    const rows = D.deals.map((d) => {
      const expired = d.validTill && d.validTill < today;
      return `<tr><td>${thumb(d.image, '🎁')}</td>
        <td><b>${esc(d.title)}</b><div class="muted">${esc(d.includes)}</div></td>
        <td>${money(d.price)}${d.oldPrice > 0 ? `<div class="muted"><del>${money(d.oldPrice)}</del></div>` : ''}</td>
        <td>${d.validTill ? esc(d.validTill) + (expired ? ' <span class="tag off">Expired</span>' : '') : '<span class="muted">No end date</span>'}</td>
        <td>${toggle(d.active, `data-toggle="deals" data-id="${d.id}" data-key="active"`)}</td>
        <td class="actions"><button class="btn sm" data-edit="deals" data-id="${d.id}">Edit</button><button class="btn sm danger" data-del="deals" data-id="${d.id}" data-name="${esc(d.title)}">Delete</button></td></tr>`;
    }).join('');
    return `<div class="bar"><div class="grow muted">Deals show on the website Deals page. Use the switch to hide a deal without deleting it.</div><button class="btn primary" data-add="deals">+ New deal</button></div>
      ${D.deals.length ? `<div class="tbl-wrap"><table><thead><tr><th></th><th>Deal</th><th>Price</th><th>Valid till</th><th>Visible</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="panel empty">No deals yet. Click "+ New deal".</div>'}`;
  }

  function viewItems() {
    const list = D.items.filter((i) => itemFilter === 'all' || i.categoryId === itemFilter);
    const rows = list.map((i) => {
      const c = D.categories.find((x) => x.id === i.categoryId);
      return `<tr><td>${thumb(i.image, c?.emoji || '🍰')}</td>
        <td><b>${esc(i.name)}</b>${i.featured ? ' <span class="tag">Popular</span>' : ''}<div class="muted">${esc(i.description).slice(0, 70)}</div></td>
        <td>${esc(catName(i.categoryId))}</td><td>${money(i.price)}</td>
        <td>${toggle(i.available, `data-toggle="items" data-id="${i.id}" data-key="available"`)}</td>
        <td class="actions"><button class="btn sm" data-edit="items" data-id="${i.id}">Edit</button><button class="btn sm danger" data-del="items" data-id="${i.id}" data-name="${esc(i.name)}">Delete</button></td></tr>`;
    }).join('');
    const groups = ['bakery', 'food'].map((g) => `<optgroup label="${g === 'bakery' ? 'Bakery' : 'Biryani & Food'}">${D.categories.filter((c) => c.group === g).map((c) => `<option value="${esc(c.id)}" ${itemFilter === c.id ? 'selected' : ''}>${esc(c.emoji)} ${esc(c.name)}</option>`).join('')}</optgroup>`).join('');
    return `<div class="bar"><select id="ifilter" class="btn" style="font-weight:500"><option value="all">All categories</option>${groups}</select>
      <div class="grow muted">${list.length} item${list.length === 1 ? '' : 's'}</div><button class="btn primary" data-add="items">+ New item</button></div>
      ${list.length ? `<div class="tbl-wrap"><table><thead><tr><th></th><th>Item</th><th>Category</th><th>Price</th><th>Available</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="panel empty">No items here yet.</div>'}`;
  }

  function viewCategories() {
    const label = { bakery: 'Bakery', food: 'Biryani & Food' };
    const rows = D.categories.map((c) => `<tr><td style="font-size:1.6rem">${esc(c.emoji)}</td><td><b>${esc(c.name)}</b></td>
      <td><span class="tag">${label[c.group]}</span></td><td>${D.items.filter((i) => i.categoryId === c.id).length}</td><td>${c.order}</td>
      <td class="actions"><button class="btn sm" data-edit="categories" data-id="${c.id}">Edit</button><button class="btn sm danger" data-del="categories" data-id="${c.id}" data-name="${esc(c.name)}">Delete</button></td></tr>`).join('');
    return `<div class="bar"><div class="grow muted">Categories decide how the menu is organised on the website.</div><button class="btn primary" data-add="categories">+ New category</button></div>
      <div class="tbl-wrap"><table><thead><tr><th></th><th>Name</th><th>Section</th><th>Items</th><th>Order</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  function viewReviews() {
    const rows = D.reviews.map((r) => `<tr>
      <td><b>${esc(r.name)}</b><div class="muted">${r.date ? new Date(r.date).toLocaleDateString('en-GB') : ''}</div></td>
      <td style="color:#e8a33d;white-space:nowrap">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</td>
      <td style="max-width:360px">${esc(r.text)}</td>
      <td>${r.approved ? '<span class="tag ok">Live</span>' : '<span class="tag pending">Pending</span>'}</td>
      <td class="actions">${r.approved ? `<button class="btn sm" data-hide="${r.id}">Hide</button>` : `<button class="btn sm good" data-approve="${r.id}">Approve</button>`}
        <button class="btn sm" data-edit="reviews" data-id="${r.id}">Edit</button><button class="btn sm danger" data-del="reviews" data-id="${r.id}" data-name="this review">Delete</button></td></tr>`).join('');
    return `<div class="bar"><div class="grow muted">New customer reviews wait here until you approve them.</div><button class="btn primary" data-add="reviews">+ Add review</button></div>
      ${D.reviews.length ? `<div class="tbl-wrap"><table><thead><tr><th>Customer</th><th>Rating</th><th>Review</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="panel empty">No reviews yet.</div>'}`;
  }

  function viewSettings() {
    const s = D.settings;
    const f = (k, label, hint, type = 'text') => `<div class="f ${['heroText'].includes(k) ? 'full' : ''}"><label>${label}</label>${k === 'heroText' ? `<textarea name="${k}" rows="3">${esc(s[k])}</textarea>` : `<input type="${type}" name="${k}" value="${esc(s[k])}">`}${hint ? `<small>${hint}</small>` : ''}</div>`;
    return `<form id="settingsForm" class="panel"><h3>Website information</h3><p class="hint">This appears on the website header, footer, home page and contact page.</p>
      <div class="fgrid">
        ${f('businessName', 'Business name')}${f('tagline', 'Tagline')}
        ${f('heroTitle', 'Home page headline')}${f('heroText', 'Home page text')}
        ${f('phone', 'Phone number')}${f('whatsapp', 'WhatsApp number', 'With country code, no + or spaces. Example: 923001234567')}
        ${f('email', 'Email (shown on website)')}${f('hours', 'Opening hours')}
        <div class="f full"><label>Address</label><input type="text" name="address" value="${esc(s.address)}"></div>
        ${f('facebook', 'Facebook page link')}${f('instagram', 'Instagram link')}
      </div><div class="form-actions"><button class="btn primary" type="submit">Save settings</button></div></form>`;
  }

  function viewAccount() {
    return `<form id="accountForm" class="panel" style="max-width:520px"><h3>Login details</h3>
      <p class="hint">You log in with this email. Change the email or password here. Leave a field empty to keep it as it is.</p>
      <div class="f"><label>Current password *</label><input type="password" name="currentPassword" required autocomplete="current-password"></div>
      <div class="f"><label>New email</label><input type="email" name="newEmail" placeholder="${esc(me.email)}" autocomplete="off"></div>
      <div class="f"><label>New password</label><input type="password" name="newPassword" minlength="8" autocomplete="new-password"><small>At least 8 characters</small></div>
      <div class="form-actions"><button class="btn primary" type="submit">Update</button></div></form>`;
  }

  const TITLES = { dashboard: 'Dashboard', deals: 'Deals', items: 'Menu Items', categories: 'Categories', reviews: 'Reviews', settings: 'Website Info', account: 'Account' };
  const VIEWS = { dashboard: viewDashboard, deals: viewDeals, items: viewItems, categories: viewCategories, reviews: viewReviews, settings: viewSettings, account: viewAccount };

  function renderNav() {
    const pending = D.reviews.filter((r) => !r.approved).length;
    const links = [['dashboard', '📊', 'Dashboard'], ['deals', '🎁', 'Deals'], ['items', '🍰', 'Menu Items'], ['categories', '🗂️', 'Categories'], ['reviews', '⭐', 'Reviews'], ['settings', '⚙️', 'Website Info'], ['account', '🔑', 'Account']];
    $('#nav').innerHTML = links.map(([k, i, t]) => `<button class="navlink ${tab === k ? 'active' : ''}" data-go="${k}">${i} ${t}${k === 'reviews' && pending ? `<span class="count">${pending}</span>` : ''}</button>`).join('');
    $('#nav').querySelectorAll('[data-go]').forEach((el) => (el.onclick = () => go(el.dataset.go)));
  }

  function render() {
    if (!VIEWS[tab]) tab = 'dashboard';
    $('#title').textContent = TITLES[tab];
    $('#view').innerHTML = VIEWS[tab]();
    renderNav();
    $('#sidebar').classList.remove('open');
    bind();
  }

  function go(t) { tab = t; location.hash = t; render(); window.scrollTo(0, 0); }

  /* ---------- events ---------- */
  function bind() {
    const v = $('#view');
    v.querySelectorAll('[data-go]').forEach((el) => (el.onclick = (e) => { e.preventDefault(); go(el.dataset.go); }));
    v.querySelectorAll('[data-add]').forEach((el) => (el.onclick = () => openForm(el.dataset.add)));
    v.querySelectorAll('[data-edit]').forEach((el) => (el.onclick = () => {
      const k = el.dataset.edit;
      openForm(k, D[k].find((r) => r.id === el.dataset.id));
    }));
    v.querySelectorAll('[data-del]').forEach((el) => (el.onclick = () => {
      if (confirm(`Delete ${el.dataset.name}? This cannot be undone.`)) run(() => api('DELETE', `/api/admin/${el.dataset.del}/${el.dataset.id}`), 'Deleted');
    }));
    v.querySelectorAll('[data-toggle]').forEach((el) => (el.onchange = () =>
      run(() => api('PUT', `/api/admin/${el.dataset.toggle}/${el.dataset.id}`, { [el.dataset.key]: el.checked }), 'Updated')));
    v.querySelectorAll('[data-approve]').forEach((el) => (el.onclick = () => run(() => api('PUT', `/api/admin/reviews/${el.dataset.approve}`, { approved: true }), 'Review is live')));
    v.querySelectorAll('[data-hide]').forEach((el) => (el.onclick = () => run(() => api('PUT', `/api/admin/reviews/${el.dataset.hide}`, { approved: false }), 'Review hidden')));
    const flt = $('#ifilter');
    if (flt) flt.onchange = () => { itemFilter = flt.value; render(); };

    const sf = $('#settingsForm');
    if (sf) sf.onsubmit = (e) => { e.preventDefault(); run(() => api('PUT', '/api/admin/settings', Object.fromEntries(new FormData(sf))), 'Settings saved'); };

    const af = $('#accountForm');
    if (af) af.onsubmit = async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(af));
      if (!body.newEmail && !body.newPassword) return toast('Enter a new email or password', true);
      try {
        const r = await api('PUT', '/api/admin/account', body);
        me.email = r.email; me.mustChange = me.mustChange && !body.newPassword;
        $('#who').textContent = me.email;
        af.reset(); toast('Login details updated');
      } catch (err) { toast(err.message, true); }
    };
  }

  $('#burger').onclick = () => $('#sidebar').classList.toggle('open');
  $('#logout').onclick = async () => { await api('POST', '/api/admin/logout').catch(() => {}); location.replace('/admin/login'); };
  window.addEventListener('hashchange', () => { const t = location.hash.slice(1); if (t && t !== tab && VIEWS[t]) { tab = t; render(); } });

  /* ---------- boot ---------- */
  (async () => {
    try {
      me = await api('GET', '/api/admin/me');
      await reload();
    } catch { return; }
    $('#who').textContent = me.email;
    render();
  })();
})();
