/* The Desi Bakers - public site */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => (Number(n) > 0 ? 'Rs. ' + Number(n).toLocaleString('en-PK') : 'Call for price');
  const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
  const page = document.body.dataset.page;

  const NAV = [['/', 'Home', 'home'], ['/menu', 'Menu', 'menu'], ['/deals', 'Deals', 'deals'], ['/reviews', 'Reviews', 'reviews'], ['/contact', 'Contact', 'contact']];

  let D; // all data from server

  const waLink = (text) => `https://wa.me/${D.settings.whatsapp}?text=${encodeURIComponent(text)}`;
  const catOf = (id) => D.categories.find((c) => c.id === id);

  /* ---------- shared layout ---------- */
  function layout() {
    const s = D.settings;
    document.title = (page === 'home' ? '' : ({ menu: 'Menu', deals: 'Deals', reviews: 'Reviews', contact: 'Contact' }[page] + ' | ')) + s.businessName;
    $('#header').outerHTML = `
      <header class="site-header"><div class="container nav">
        <a href="/" class="brand">🥐 <span>${esc(s.businessName)}<small>${esc(s.tagline)}</small></span></a>
        <button class="menu-toggle" aria-label="Menu" id="mt">☰</button>
        <nav class="nav-links" id="nl">${NAV.map(([h, t, k]) => `<a href="${h}" class="${k === page ? 'active' : ''}">${t}</a>`).join('')}</nav>
      </div></header>`;
    $('#mt').onclick = () => $('#nl').classList.toggle('open');

    const social = [s.facebook && `<li><a href="${esc(s.facebook)}" target="_blank" rel="noopener">Facebook</a></li>`, s.instagram && `<li><a href="${esc(s.instagram)}" target="_blank" rel="noopener">Instagram</a></li>`].filter(Boolean).join('');
    $('#footer').outerHTML = `
      <footer class="site-footer"><div class="container">
        <div class="foot-grid">
          <div><h4>${esc(s.businessName)}</h4><p>${esc(s.tagline)}</p></div>
          <div><h4>Quick links</h4><ul>${NAV.map(([h, t]) => `<li><a href="${h}">${t}</a></li>`).join('')}</ul></div>
          <div><h4>Visit us</h4><p>${esc(s.address)}</p><p>${esc(s.hours)}</p><p>📞 ${esc(s.phone)}</p>${social ? `<ul style="margin-top:8px">${social}</ul>` : ''}</div>
        </div>
        <div class="copy">© ${new Date().getFullYear()} ${esc(s.businessName)}. All rights reserved.</div>
      </div></footer>
      <a class="wa-float" href="${waLink('Assalam o Alaikum! I want to place an order.')}" target="_blank" rel="noopener" aria-label="WhatsApp">💬</a>`;
  }

  /* ---------- reusable cards ---------- */
  function itemCard(it) {
    const c = catOf(it.categoryId);
    const img = it.image ? `<img src="${esc(it.image)}" alt="${esc(it.name)}" loading="lazy">` : `<div class="ph">${esc(c?.emoji || '🍰')}</div>`;
    const sold = !it.available;
    const order = waLink(`Assalam o Alaikum! I want to order: ${it.name} (${money(it.price)})`);
    return `<article class="card">
      <div class="card-img">${img}${sold ? '<span class="badge grey">Sold out</span>' : it.featured ? '<span class="badge gold">Popular</span>' : ''}</div>
      <div class="card-body">
        <h3>${esc(it.name)}</h3>
        <p class="desc">${esc(it.description)}</p>
        <div class="card-foot"><span class="price">${money(it.price)}</span>
        <a class="btn btn-wa btn-sm ${sold ? 'disabled' : ''}" href="${order}" target="_blank" rel="noopener">Order</a></div>
      </div></article>`;
  }

  function dealCard(d) {
    const img = d.image ? `<img src="${esc(d.image)}" alt="${esc(d.title)}" loading="lazy">` : `<div class="ph">🎁</div>`;
    const save = d.oldPrice > d.price && d.price > 0 ? Math.round((1 - d.price / d.oldPrice) * 100) : 0;
    const order = waLink(`Assalam o Alaikum! I want to order this deal: ${d.title} (${money(d.price)})`);
    const till = d.validTill ? `<div class="valid">Valid till ${new Date(d.validTill + 'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</div>` : '';
    return `<article class="card deal-card">
      <div class="card-img">${img}${save ? `<span class="badge">${save}% OFF</span>` : '<span class="badge">DEAL</span>'}</div>
      <div class="card-body">
        <h3>${esc(d.title)}</h3>
        ${d.includes ? `<div class="includes">🍽️ ${esc(d.includes)}</div>` : ''}
        <p class="desc">${esc(d.description)}</p>${till}
        <div class="card-foot"><span class="price">${money(d.price)}${d.oldPrice > d.price ? `<del>${money(d.oldPrice)}</del>` : ''}</span>
        <a class="btn btn-wa btn-sm" href="${order}" target="_blank" rel="noopener">Order deal</a></div>
      </div></article>`;
  }

  function reviewCard(r) {
    return `<div class="review"><div class="stars">${stars(r.rating)}</div><p>${esc(r.text)}</p>
      <div class="who">${esc(r.name)}</div>${r.date ? `<div class="when">${new Date(r.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</div>` : ''}</div>`;
  }

  const countIn = (cid) => D.items.filter((i) => i.categoryId === cid).length;

  /* ---------- pages ---------- */
  function home() {
    const s = D.settings;
    const featured = D.items.filter((i) => i.featured && i.available).slice(0, 4);
    const deals = D.deals.slice(0, 3);
    const revs = D.reviews.slice(0, 3);
    $('#main').innerHTML = `
      <section class="hero" data-emoji="🥐"><div class="container"><div class="hero-inner">
        <span class="eyebrow">${esc(s.tagline)}</span>
        <h1>${esc(s.heroTitle)}</h1><p>${esc(s.heroText)}</p>
        <div class="hero-cta"><a class="btn btn-primary" href="/menu">View menu</a><a class="btn btn-ghost" href="/deals">Today's deals</a></div>
      </div></div></section>

      <section class="section"><div class="container">
        <div class="section-head"><div><h2>Our categories</h2><p>Pick what you are craving</p></div></div>
        <div class="cat-grid">${D.categories.map((c) => `<a class="cat-tile" href="/menu?cat=${esc(c.id)}"><span class="em">${esc(c.emoji)}</span><b>${esc(c.name)}</b><small>${countIn(c.id)} item${countIn(c.id) === 1 ? '' : 's'}</small></a>`).join('')}</div>
      </div></section>

      ${deals.length ? `<section class="section alt"><div class="container">
        <div class="section-head"><div><h2>Hot deals 🔥</h2><p>Save more when you order a deal</p></div><a class="link-more" href="/deals">All deals →</a></div>
        <div class="grid">${deals.map(dealCard).join('')}</div></div></section>` : ''}

      ${featured.length ? `<section class="section"><div class="container">
        <div class="section-head"><div><h2>Customer favourites</h2><p>The ones everybody keeps ordering</p></div><a class="link-more" href="/menu">Full menu →</a></div>
        <div class="grid">${featured.map(itemCard).join('')}</div></div></section>` : ''}

      ${revs.length ? `<section class="section alt"><div class="container">
        <div class="section-head"><div><h2>What people say</h2><p>${D.rating.average} ★ from ${D.rating.count} review${D.rating.count > 1 ? 's' : ''}</p></div><a class="link-more" href="/reviews">All reviews →</a></div>
        <div class="grid">${revs.map(reviewCard).join('')}</div></div></section>` : ''}`;
  }

  function menu() {
    const qs = new URLSearchParams(location.search);
    const startCat = qs.get('cat');
    const startGroup = startCat ? catOf(startCat)?.group || 'all' : 'all';
    const state = { group: startGroup, cat: catOf(startCat) ? startCat : 'all', q: '' };
    $('#main').innerHTML = `
      <div class="page-title"><div class="container"><h1>Our Menu</h1><p>Bakery items and desi food, fresh every day</p></div></div>
      <div class="menu-bar"><div class="container">
        <div class="menu-top"><div class="tabs" id="tabs"></div><input class="search" id="q" type="search" placeholder="Search items..."></div>
        <div class="chips" id="chips"></div>
      </div></div>
      <div class="container" id="list" style="padding-bottom:30px"></div>`;

    const groups = [['all', 'All'], ['bakery', '🧁 Bakery'], ['food', '🍛 Biryani & Food']];
    function draw() {
      $('#tabs').innerHTML = groups.map(([k, t]) => `<button class="tab ${state.group === k ? 'active' : ''}" data-g="${k}">${t}</button>`).join('');
      const cats = D.categories.filter((c) => state.group === 'all' || c.group === state.group);
      $('#chips').innerHTML = `<button class="chip ${state.cat === 'all' ? 'active' : ''}" data-c="all">All</button>` +
        cats.map((c) => `<button class="chip ${state.cat === c.id ? 'active' : ''}" data-c="${esc(c.id)}">${esc(c.emoji)} ${esc(c.name)}</button>`).join('');
      const q = state.q.toLowerCase();
      const html = cats.filter((c) => state.cat === 'all' || state.cat === c.id).map((c) => {
        const its = D.items.filter((i) => i.categoryId === c.id && (!q || (i.name + ' ' + i.description).toLowerCase().includes(q)));
        return its.length ? `<section class="menu-section"><h2>${esc(c.emoji)} ${esc(c.name)}</h2><div class="grid">${its.map(itemCard).join('')}</div></section>` : '';
      }).join('');
      $('#list').innerHTML = html || '<div class="empty">Nothing found. Try another search or category.</div>';
    }
    $('#tabs').onclick = (e) => { const b = e.target.closest('[data-g]'); if (b) { state.group = b.dataset.g; state.cat = 'all'; draw(); } };
    $('#chips').onclick = (e) => { const b = e.target.closest('[data-c]'); if (b) { state.cat = b.dataset.c; draw(); } };
    $('#q').oninput = (e) => { state.q = e.target.value.trim(); draw(); };
    draw();
  }

  function deals() {
    $('#main').innerHTML = `
      <div class="page-title"><div class="container"><h1>Deals & Offers</h1><p>Special combos at special prices</p></div></div>
      <section class="section"><div class="container">${D.deals.length ? `<div class="grid">${D.deals.map(dealCard).join('')}</div>` :
        '<div class="empty"><div style="font-size:3rem">🎁</div><p>No active deals right now. Check back soon!</p></div>'}</div></section>`;
  }

  function reviews() {
    $('#main').innerHTML = `
      <div class="page-title"><div class="container"><h1>Customer Reviews</h1><p>Your words keep us baking</p></div></div>
      <section class="section"><div class="container">
        ${D.rating.count ? `<div class="rating-summary"><span class="big">${D.rating.average}</span><div><div class="stars">${stars(Math.round(D.rating.average))}</div><small>${D.rating.count} review${D.rating.count > 1 ? 's' : ''}</small></div></div>
        <div class="grid" style="margin-bottom:50px">${D.reviews.map(reviewCard).join('')}</div>` : '<div class="empty" style="margin-bottom:30px">No reviews yet. Be the first to share your experience!</div>'}
        <form class="form-card" id="rf">
          <h3>Write a review</h3><div id="rmsg"></div>
          <div class="field"><label>Your name</label><input name="name" maxlength="60" required></div>
          <div class="field"><label>Rating</label><div class="star-input">
            ${[5, 4, 3, 2, 1].map((n) => `<input type="radio" name="rating" id="s${n}" value="${n}" ${n === 5 ? 'checked' : ''}><label for="s${n}" title="${n} stars">★</label>`).join('')}</div></div>
          <div class="field"><label>Your review</label><textarea name="text" rows="4" maxlength="600" required></textarea></div>
          <input class="hp" name="website" tabindex="-1" autocomplete="off">
          <button class="btn btn-maroon" type="submit">Submit review</button>
          <p style="font-size:.8rem;color:var(--brown-2);margin-top:10px">Reviews appear on the site after approval.</p>
        </form>
      </div></section>`;
    $('#rf').onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target, btn = f.querySelector('button');
      btn.disabled = true;
      try {
        const r = await fetch('/api/reviews', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(f))) });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || 'Something went wrong');
        f.reset();
        $('#rmsg').innerHTML = '<div class="msg ok">Thank you! Your review will appear once approved.</div>';
      } catch (err) {
        $('#rmsg').innerHTML = `<div class="msg err">${esc(err.message)}</div>`;
      }
      btn.disabled = false;
    };
  }

  function contact() {
    const s = D.settings;
    const map = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(s.address);
    $('#main').innerHTML = `
      <div class="page-title"><div class="container"><h1>Contact Us</h1><p>Orders, custom cakes, bulk and party deals</p></div></div>
      <section class="section"><div class="container">
        <div class="contact-grid">
          <div class="info-box"><div class="em">📞</div><h3>Call us</h3><a href="tel:${esc(s.phone.replace(/[^\d+]/g, ''))}">${esc(s.phone)}</a></div>
          <div class="info-box"><div class="em">💬</div><h3>WhatsApp</h3><a href="${waLink('Assalam o Alaikum!')}" target="_blank" rel="noopener">Chat with us</a></div>
          <div class="info-box"><div class="em">📍</div><h3>Address</h3><a href="${map}" target="_blank" rel="noopener">${esc(s.address)}</a></div>
          <div class="info-box"><div class="em">🕒</div><h3>Opening hours</h3><p>${esc(s.hours)}</p></div>
          ${s.email ? `<div class="info-box"><div class="em">✉️</div><h3>Email</h3><a href="mailto:${esc(s.email)}">${esc(s.email)}</a></div>` : ''}
        </div>
        <div style="text-align:center;margin-top:34px"><a class="btn btn-wa" href="${waLink('Assalam o Alaikum! I want to place an order.')}" target="_blank" rel="noopener">Order on WhatsApp</a></div>
      </div></section>`;
  }

  /* ---------- boot ---------- */
  (async () => {
    try {
      const r = await fetch('/api/public');
      D = await r.json();
    } catch {
      $('#main').innerHTML = '<div class="loading">Could not load. Please refresh the page.</div>';
      return;
    }
    layout();
    ({ home, menu, deals, reviews, contact }[page] || home)();
  })();
})();
