# The Desi Bakers

Website + admin panel. No database to install and no `npm install` needed. Only **Node.js 18 or newer**.

## Run locally

```bash
node server.js
```
Open http://localhost:3000 and the admin panel at http://localhost:3000/admin

First run prints the default admin login:

- Email: `admin@thedesibakers.com`
- Password: `Admin@12345`

Log in and change both from **Account** straight away.
To start with your own login, set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before the very first run.

## Run without a terminal (double-click)

1. Install Node.js (LTS) from https://nodejs.org, normal Next-Next installer.
2. Extract the zip.
3. **Windows:** double-click `start.bat`. **Mac:** double-click `start.command`.
4. The website opens in your browser. Admin is at http://localhost:3000/admin
5. Close the black window to stop the server.

## What the client can do from /admin

| Section | What it does |
|---|---|
| Deals | Add / edit / delete deals with photo, price, old price, end date. Switch hides a deal. |
| Menu Items | Add items to any category, photo, price, Sold-out switch, "Popular" flag. |
| Categories | Pastries, Cakes, Patties, Frozen (Bakery section) and Biryani, Pulao (Food section). Add more any time. |
| Reviews | Customers submit reviews on the site; they go live only after approval. |
| Website Info | Name, phone, WhatsApp number, address, hours, home page text, social links. |
| Account | Change login email and password. |

Orders go to the shop's WhatsApp (set the number in **Website Info**, format `923001234567`).

## Put it on a server (VPS, Ubuntu example)

1. Install Node 18+ (`curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs`)
2. Upload this folder to the server, e.g. `/var/www/desi-bakers`
3. Keep it running with pm2:
   ```bash
   sudo npm i -g pm2
   cd /var/www/desi-bakers
   ADMIN_EMAIL=owner@example.com ADMIN_PASSWORD='strong-password' pm2 start server.js --name desi-bakers
   pm2 save && pm2 startup
   ```
4. Nginx in front (domain + free SSL):
   ```nginx
   server {
     server_name thedesibakers.com www.thedesibakers.com;
     client_max_body_size 10m;
     location / {
       proxy_pass http://127.0.0.1:3000;
       proxy_set_header Host $host;
       proxy_set_header X-Forwarded-For $remote_addr;
       proxy_set_header X-Forwarded-Proto $scheme;
     }
   }
   ```
   Then `sudo certbot --nginx -d thedesibakers.com -d www.thedesibakers.com`

**cPanel / shared hosting:** use "Setup Node.js App", set startup file to `server.js`, and the app URL to your domain.

## Important

- **Backup the `data/` folder.** It holds everything: items, deals, reviews, login, uploaded photos. Do not overwrite it when you upload a new version of the code.
- You can move it elsewhere with `DATA_DIR=/path/to/data`.
- Always use HTTPS in production (the admin cookie becomes `Secure` automatically behind nginx).
- Login is rate limited (8 tries / 15 min per IP).

## Files

```
server.js            backend (API, login, uploads)
public/              website pages (index, menu, deals, reviews, contact)
public/admin/        admin panel
data/                created on first run (database + photos)
```
