@echo off
title The Desi Bakers - server (close this window to stop)
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is not installed. Download it from https://nodejs.org ^(LTS^), install it, then double-click this file again.
  echo.
  pause
  exit /b
)
echo.
echo  Website : http://localhost:3000
echo  Admin   : http://localhost:3000/admin
echo.
start "" /b cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:3000"
node server.js
pause
